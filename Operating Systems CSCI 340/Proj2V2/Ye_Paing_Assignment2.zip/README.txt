COMPILE USING G++
1)Compile: g++ *.cpp -o (filename)
2)Run: ./(filename)
