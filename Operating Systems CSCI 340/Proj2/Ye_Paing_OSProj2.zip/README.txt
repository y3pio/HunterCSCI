RUN/COMPILE INSTRUCTIONS!

1)Compule with g++:
	g++ *.cpp -o (output)

3)Run with:
	./(output)
