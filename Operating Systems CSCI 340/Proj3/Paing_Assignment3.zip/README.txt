Compile And Run Instructions

1)Compile with g++ compiler:
	g++ *.cpp -o (progname)

2)Run:
	./(progname)